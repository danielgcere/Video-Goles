//Importamos todas las clases que necesita el Presenter (Arquitectura VIP).
const GenericPresenter = require('../Presenters/GenericPresenter');

//Exportamos todas las clases que necesita el Presenter (Arquitectura VIP).
module.exports.GenericPresenter = GenericPresenter;
